type SimpleIconProps = {
  path: string;
  size?: number;
  className?: string;
};

export const SimpleIcon = ({
  path,
  size = 20,
  className,
}: SimpleIconProps) => (
  <svg
    viewBox="0 0 24 24"
    width="24"
    height="24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    className={className}
    aria-hidden="true"
    dangerouslySetInnerHTML={{ __html: path }}
    stroke-linecap="round"
    stroke-linejoin="round"
  />
);