import { Button } from "@/components/ui/button";
import { Play, ArrowRight } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => {
  const scrollToPortfolio = () => {
    document.getElementById("portfolio")?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img 
          src={heroBg} 
          alt="Professional video production"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 video-overlay" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/70 to-transparent" />
      </div>

      {/* Ambient Glow Effects */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] animate-pulse" />
      <div className="absolute bottom-1/3 left-1/3 w-64 h-64 bg-primary/10 rounded-full blur-[100px] animate-pulse delay-300" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 py-20">
        <div className="max-w-4xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-border/50 mb-8 opacity-0 animate-fade-up">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-medium text-muted-foreground">
              Video & Design Agency
            </span>
          </div>

          {/* Headline */}
          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.1] mb-6 opacity-0 animate-fade-up delay-100">
            Captivating brand videos that help{" "}
            <span className="text-gradient-accent">startups grow</span>
          </h1>

          {/* Subheadline */}
          <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed max-w-2xl mb-10 opacity-0 animate-fade-up delay-200">
            Short reels, crisp brand design, measurable results — built for 
            startups and local businesses ready to stand out.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 opacity-0 animate-fade-up delay-300">
            <Button 
              variant="hero" 
              size="xl"
              onClick={scrollToContact}
              className="group"
            >
              Request Quote
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button 
              variant="heroOutline" 
              size="xl"
              onClick={scrollToPortfolio}
              className="group"
            >
              <Play className="w-5 h-5" />
              View Reel
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="flex flex-wrap gap-8 mt-16 pt-8 border-t border-border/30 opacity-0 animate-fade-up delay-400">
            <div>
              <div className="font-display text-3xl font-bold text-foreground">10+</div>
              <div className="text-sm text-muted-foreground">Local Brands Served</div>
            </div>
            <div>
              <div className="font-display text-3xl font-bold text-foreground">40%</div>
              <div className="text-sm text-muted-foreground">Avg. Engagement Lift</div>
            </div>
            <div>
              <div className="font-display text-3xl font-bold text-foreground">4.6★</div>
              <div className="text-sm text-muted-foreground">Client Reviews</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 opacity-0 animate-fade-up delay-500">
        <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/50 flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-primary rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
