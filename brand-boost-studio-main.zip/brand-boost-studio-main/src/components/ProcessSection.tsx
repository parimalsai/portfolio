import { useEffect, useRef, useState } from "react";
import { MessageSquare, Sparkles, Rocket, Clock, TrendingUp, Heart } from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Brief",
    description:
      "We start with a quick call to understand your goals, audience, and vision. No jargon, just a real conversation.",
    icon: MessageSquare,
  },
  {
    number: "02",
    title: "Create",
    description:
      "I handle everything — concept, filming, editing, and revisions. You stay focused on running your business.",
    icon: Sparkles,
  },
  {
    number: "03",
    title: "Deliver & Measure",
    description:
      "You get polished assets ready to post, plus tips on when and where to share for maximum impact.",
    icon: Rocket,
  },
];

const benefits = [
  {
    icon: Clock,
    title: "Save Time",
    description: "No endless back-and-forth. From brief to final delivery in days, not weeks.",
  },
  {
    icon: TrendingUp,
    title: "Boost Engagement",
    description: "Content designed to stop the scroll and get people talking about your brand.",
  },
  {
    icon: Heart,
    title: "Build Trust",
    description: "Professional visuals that make your business look as good as it actually is.",
  },
];

const ProcessSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-background">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            How It Works
          </span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            Simple Process, Real Results
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            No complicated workflows or endless meetings. Just a straightforward 
            path to content that actually works.
          </p>
        </div>

        {/* Process Steps */}
        <div className="grid md:grid-cols-3 gap-8 mb-24">
          {steps.map((step, index) => (
            <div
              key={step.number}
              className={`relative transition-all duration-700 ${
                isVisible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-full w-full h-px bg-gradient-to-r from-border to-transparent z-0" />
              )}

              <div className="relative bg-card rounded-2xl p-8 border border-border/50 hover:border-primary/30 transition-colors group">
                {/* Step Number */}
                <div className="absolute -top-4 -left-4 w-12 h-12 rounded-xl bg-primary flex items-center justify-center font-display font-bold text-primary-foreground shadow-glow">
                  {step.number}
                </div>

                {/* Icon */}
                <div className="w-14 h-14 rounded-xl bg-secondary flex items-center justify-center mb-6 mt-4 group-hover:bg-primary/10 transition-colors">
                  <step.icon className="w-7 h-7 text-primary" />
                </div>

                {/* Content */}
                <h3 className="font-display text-2xl font-bold text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Benefits */}
        <div
          className={`transition-all duration-700 delay-500 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <h3 className="font-display text-2xl font-bold text-center mb-12">
            Why Work With Me?
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-6 rounded-xl bg-secondary/30 border border-border/30 hover:border-primary/20 transition-colors"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <benefit.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-1">
                    {benefit.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {benefit.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
