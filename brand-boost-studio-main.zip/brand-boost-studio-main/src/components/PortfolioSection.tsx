import { useState, useEffect, useRef } from "react";
import { ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

import portfolio1 from "@/assets/portfolio-1.png";
import portfolio2 from "@/assets/portfolio-2.png";
import portfolio3 from "@/assets/portfolio-3.png";
import portfolio4 from "@/assets/portfolio-4.png";
import portfolio5 from "@/assets/portfolio-5.png";
import portfolio6 from "@/assets/portfolio-6.png";

interface Project {
  id: number;
  title: string;
  category: string;
  image: string;
  problem: string;
  solution: string;
  result: string;
  metric: string;
}

const projects: Project[] = [
  {
    id: 1,
    title: "Brew & Co. Coffee",
    category: "Brand Video",
    image: portfolio1,
    problem: "Low local awareness in a competitive market",
    solution: "30-second social reel showcasing the cafe experience",
    result: "40% uplift in social engagement",
    metric: "+40%",
  },
  {
    id: 2,
    title: "TechStart Hub",
    category: "Corporate Video",
    image: portfolio2,
    problem: "Struggled to attract top talent",
    solution: "Company culture video for recruitment",
    result: "Doubled qualified applicants",
    metric: "2x",
  },
  {
    id: 3,
    title: "Urban Grill House",
    category: "Food Photography",
    image: portfolio3,
    problem: "Menu photos didn't match quality",
    solution: "Full menu photoshoot with styling",
    result: "Online orders increased 35%",
    metric: "+35%",
  },
  {
    id: 4,
    title: "FitForce Gym",
    category: "Promo Video",
    image: portfolio4,
    problem: "Low membership sign-ups",
    solution: "High-energy promotional video",
    result: "Membership inquiries tripled",
    metric: "3x",
  },
  {
    id: 5,
    title: "Luxe Properties",
    category: "Real Estate Video",
    image: portfolio5,
    problem: "Properties sat on market too long",
    solution: "Cinematic property walkthrough videos",
    result: "Avg. time to sale reduced by 25%",
    metric: "-25%",
  },
  {
    id: 6,
    title: "Nova Records",
    category: "Music Video",
    image: portfolio6,
    problem: "Artist needed breakout content",
    solution: "Music video + social edits package",
    result: "500K+ views in first month",
    metric: "500K+",
  },
];

const PortfolioSection = () => {
  const [visibleItems, setVisibleItems] = useState<Set<number>>(new Set());
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute("data-index") || "0");
            setVisibleItems((prev) => new Set(prev).add(index));
          }
        });
      },
      { threshold: 0.2 }
    );

    itemRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section id="portfolio" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Portfolio
          </span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            Work That Speaks for Itself
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From brand videos to full identity kits — every project is built to 
            get real, measurable results for your business.
          </p>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <div
              key={project.id}
              ref={(el) => (itemRefs.current[index] = el)}
              data-index={index}
              className={`group relative rounded-2xl overflow-hidden card-gradient border border-border/50 transition-all duration-500 ${
                visibleItems.has(index)
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              {/* Image */}
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Button
            variant="outline"
            size="lg"
            onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
          >
            Start Your Project
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>

    </section>
  );
};

export default PortfolioSection;
