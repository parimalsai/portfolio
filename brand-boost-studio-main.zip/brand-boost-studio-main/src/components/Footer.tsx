import { Youtube, Instagram, Linkedin, Heart } from "lucide-react";
import { FaBehance } from "react-icons/fa"
import { FaXTwitter } from "react-icons/fa6"
import { SimpleIcon } from "./ui/SimpleIcon";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    {
      name: "Behance",
      href: "https://www.behance.net/gallery/232077387/Youtube-Thumbnails",
      icon: FaBehance
    },
    {
      name: "X",
      href: "https://x.com/PBobbadi35048",
      icon: FaXTwitter
    },
    {
      name: "Instagram",
      href: "https://www.instagram.com/motiongency?igsh=cmE1aDFoeXkzeDI=",
      icon: Instagram,
    },
    {
      name: "LinkedIn",
      href: "https://www.linkedin.com/in/parimalsai-bobbadi?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      icon: Linkedin,
    },
  ];

  return (
    <footer className="py-12 bg-background border-t border-border">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo / Name */}
          <div className="flex items-center gap-2">
            <span className="font-display text-xl font-bold text-foreground">
              Motion<span className="text-primary">agency</span>
            </span>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            {socialLinks.map((link) => (

              <a
                key={link.name}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors"
                aria-label={`Follow on ${link.name}`}
              >
                <link.icon className="w-5 h-5" />
              </a>
            ))}
          </div>

          {/* Copyright */}
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <span>© {currentYear} Made with</span>
            <Heart className="w-4 h-4 text-primary fill-primary" />
            <span>for creatives</span>
          </div>
        </div>

        {/* Quick Links */}
        <div className="mt-8 pt-8 border-t border-border/50 flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
          <a href="#portfolio" className="hover:text-primary transition-colors">
            Portfolio
          </a>
          <a href="#contact" className="hover:text-primary transition-colors">
            Contact
          </a>
          <span>|</span>
          <span>Serving startups & local businesses worldwide</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
